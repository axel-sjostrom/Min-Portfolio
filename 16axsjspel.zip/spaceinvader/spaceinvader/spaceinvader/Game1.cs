using System; // s�tt till or�ginalstatsen efter niv� 6
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
///Axel Sj�str�m Te16a
namespace spaceinvader
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>

    public class Highscore
    {
        private int high;

        public Highscore (int h)
        {
            high = h;
        }
        
        public int High
        {
            get { return high; }
            set { high = value; }
        }
    }

    public class Var
    {
        private int lv;
        private int bpup;
        private float hp;
        private int es;
        private int point;

        public Var(int l, int b, float h, int e, int p)
        {
            lv = l;
            bpup = b;
            hp = h;
            es = e;
            point = p;
        }
        public int Lv
        {
            get { return lv; }
            set { lv = value; }
        }
        public int Bpup
        {
            get { return bpup; }
            set { bpup = value; }
        }
        public float Hp
        {
            get { return hp; }
            set { hp = value; }
        }
        public int Es
        {
            get { return es; }
            set { es = value; }
        }
        public int Point
        {
            get { return point; }
            set { point = value; }
        }
    } //Klassen �r till f�r de variabler som man vill spara

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteEffects effect;
        SpriteFont gameFont;

        List<Highscore> highList = new List<Highscore>();

        List<Var> varList = new List<Var>();
        int lv = 0;
        int bpup = 50;
        float hp = 30;
        int e = 0;
        int point = 0;

        bool ini = true; 
        bool pup = true;

        int templv;
        float temphp;

        Texture2D myship;
        Vector2 myship_pos;
        Vector2 myship_speed;
        Rectangle rec_myship;
        SoundEffect mypunch;
        int timeSinceLastHit1 = 50;

        Texture2D coin;
        Vector2 coin_pos;
        List<Vector2> coin_pos_list = new List<Vector2>();
        Rectangle rec_coin;

        Texture2D enemy;
        Vector2 enemy_pos;
        Vector2 enemy_speed;
        List<Vector2> enemy_pos_list = new List<Vector2>();
        Rectangle rec_enemy;

        Texture2D enemy2;
        Vector2 enemy2_pos;
        Vector2 enemy2_speed;
        List<Vector2> enemy2_pos_list = new List<Vector2>();
        Rectangle rec_enemy2;
        int z = 0;

        Texture2D shot;
        Vector2 shot_pos;
        Vector2 shot_speed;
        List<Vector2> shot_pos_list = new List<Vector2>();
        Rectangle rec_shot;
        int timeSinceLastBullet = 0;

        Texture2D shot2;
        Vector2 shot2_pos;
        Vector2 shot2_speed;
        List<Vector2> shot2_pos_list = new List<Vector2>();
        Rectangle rec_shot2;
        int timeSinceLastBullet2 = 0;
        int timeSinceLastHit3 = 0;

        Texture2D boss;
        Vector2 boss_pos;
        Vector2 boss_speed;
        Rectangle rec_boss;
        int bhp = 0;
        bool s = false;
        bool t = false;

        Texture2D megashot;
        Vector2 megashot_pos;
        Vector2 megashot_speed;
        List<Vector2> megashot_pos_list = new List<Vector2>();
        Rectangle rec_megashot;
        int timeSinceLastMega = 90;
        int timeSinceLastHit4 = 0;
        bool hit = false;

        int select = 0;
        int select2 = 0;

        int timeSinceLastEnter = 10;

        Song song;

        SoundEffect myshout;
        bool shout = false;
        
        SoundEffect myshot;

        SoundEffect myoof;
                
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.IsFullScreen = false;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
          
            // Initialize myship
            myship_speed.X = 10f;
            myship_speed.Y = 10f;
                        
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            myship = Content.Load<Texture2D>("Sprites/ship");
            coin = Content.Load<Texture2D>("Sprites/coin");
            enemy = Content.Load<Texture2D>("Sprites/tripod");
            enemy2 = Content.Load<Texture2D>("Sprites/coolpod");
            shot = Content.Load<Texture2D>("Sprites/bullet");
            shot2 = Content.Load<Texture2D>("Sprites/bullet2");
            boss = Content.Load<Texture2D>("Sprites/boss");
            megashot = Content.Load<Texture2D>("Sprites/mega-laser");

            myoof = Content.Load<SoundEffect>("Sounds/oof");
            myshot = Content.Load<SoundEffect>("Sounds/gun-gunshot-02");
            mypunch = Content.Load<SoundEffect>("Sounds/punch");
            myshout = Content.Load<SoundEffect>("Sounds/yehaw");
            song = Content.Load<Song>("Sounds/soundtrack");
            MediaPlayer.Play(song);

            gameFont = Content.Load<SpriteFont>("Fonts/fontmain");

            myship_pos.X = ((Window.ClientBounds.Width - myship.Width) / 2);
            myship_pos.Y = Window.ClientBounds.Height - myship.Height;

            boss_pos.X = ((Window.ClientBounds.Width - boss.Width) / 2);
            boss_pos.Y = -150;

            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        /// 

        protected override void Update(GameTime gameTime)
        {

            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here            
            KeyboardState keyboardState = Keyboard.GetState();
            
            switch (lv)
                {
                case 0:
                    menu(varList);
                    break;

                case 1:// I b�rjan av niv�n skulle jag s�tta en timer fr�n gameTime som uppeh�ller info om niv�n
                    if (ini) // Egentligen borde ini alltid skrivas som true i de h�r casen och ist�llet vara som pup i power()
                    {
                        lv1();
                        ini = false;
                    }
                    level();
                    power(20, 7);
                    terminate();
                    break;

                case 2:
                    if (!ini)
                    {
                        lv2();
                        ini = true;
                    }
                    level();
                    power(20, 7);
                    terminate();
                    break;

                case 3:
                    if(ini)
                    {
                        lv3();
                        ini = false;
                    }
                    level();
                    power(40, 7);
                    terminate();
                    break;

                case 4:
                    if (!ini)
                    {
                        lv4();
                        ini = true;
                    }
                    level();
                    power(40, 7);
                    terminate();
                    break;

                case 5:
                    if (ini)
                    {
                        lv5();
                        ini = false;
                    }
                    level();
                    power(40, 7);
                    terminate();
                    break;

                case 6:
                    if ((point > 1300) || t)
                    {
                        t = true;
                        if (!ini)
                        {
                            lv6();
                            ini = true;
                        }
                        updateboss();
                        level();
                        terminate();
                    }
                    
                    else if (point <= 2000)
                    {
                        lv = 7;
                    }
                    break;

                case 7:
                    clearall();
                    end();
                    break;

                case 8:
                    if (keyboardState.IsKeyDown(Keys.Space))
                    {
                        lv = 0;                        
                    }
                    break;
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        /// 

        ///Om du undrar varf�r allting �r en stor klump �r det f�r att jag bara kunde rita ut i Draw().            
        
        ///En f�rb�ttring vore att basera positionerna p� windows.clientbounds.width och height
        ///s� att spelet kan anpassas till fullsk�rm
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            /*
            spriteBatch.DrawString(gameFont, ("lv" + lv), new Vector2(250, 100), Color.White);
            spriteBatch.DrawString(gameFont, ("bpup" + bpup), new Vector2(250, 130), Color.White);
            spriteBatch.DrawString(gameFont, ("hp" + hp), new Vector2(250, 160), Color.White);
            spriteBatch.DrawString(gameFont, ("e" + e), new Vector2(250, 190), Color.White);
            spriteBatch.DrawString(gameFont, ("point" + point), new Vector2(250, 220), Color.White);
            
            if (ini)
            spriteBatch.DrawString(gameFont, ("true"), new Vector2(500, 300), Color.White);
            if (!ini)
            spriteBatch.DrawString(gameFont, ("false"), new Vector2(500, 300), Color.White);
            */
            switch (lv)
            { 
                case 0:
                    spriteBatch.DrawString(gameFont, ("SPACE INVADER"), new Vector2(325, 40), Color.Blue);
                    spriteBatch.DrawString(gameFont, ("SPACE INVADER"), new Vector2(327, 42), Color.Red);                                    

                    spriteBatch.DrawString(gameFont, ("Nytt Spel"), new Vector2(325, 150), Color.White);
                    
                    spriteBatch.DrawString(gameFont, ("Ladda Spel"), new Vector2(325, 200), Color.White);

                    spriteBatch.DrawString(gameFont, ("H�gsta po�ng"), new Vector2(325, 250), Color.White);

                    if (select == 0)
                        spriteBatch.DrawString(gameFont, ("*"), new Vector2(310, 153), Color.White);
                    if (select == 1)
                        spriteBatch.DrawString(gameFont, ("*"), new Vector2(310, 203), Color.White);
                    if (select == 2)
                        spriteBatch.DrawString(gameFont, ("*"), new Vector2(310, 253), Color.White);
                    break;

                case 1:
                    spriteBatch.Draw(myship, myship_pos, Color.White);
                    
                    foreach (Vector2 cn in coin_pos_list)
                        spriteBatch.Draw(coin, cn, Color.White);

                    foreach (Vector2 en in enemy_pos_list)
                        spriteBatch.Draw(enemy, en, Color.White);

                    foreach (Vector2 sh in shot_pos_list)
                        spriteBatch.Draw(shot, sh, Color.White);

                    spriteBatch.DrawString(gameFont, ("Po�ng:" + point), new Vector2(10, 10), Color.Blue);
                    spriteBatch.DrawString(gameFont, ("Liv:" + hp), new Vector2(10, 40), Color.Red);
                    spriteBatch.DrawString(gameFont, ("Niv� " + lv), new Vector2(Window.ClientBounds.Width - 100, 10), Color.White);
                    break;

                case 2:
                    spriteBatch.Draw(myship, myship_pos, Color.White);

                    foreach (Vector2 cn in coin_pos_list)
                        spriteBatch.Draw(coin, cn, Color.White);

                    foreach (Vector2 en in enemy_pos_list)
                        spriteBatch.Draw(enemy, en, Color.White);

                    foreach (Vector2 sh in shot_pos_list)
                        spriteBatch.Draw(shot, sh, Color.White);

                    spriteBatch.DrawString(gameFont, ("Po�ng:" + point), new Vector2(10, 10), Color.Blue);
                    spriteBatch.DrawString(gameFont, ("Liv:" + hp), new Vector2(10, 40), Color.Red);
                    spriteBatch.DrawString(gameFont, ("Niv� " + lv), new Vector2(Window.ClientBounds.Width - 100, 10), Color.White);
                    break;

                case 3:
                    spriteBatch.Draw(myship, myship_pos, Color.White);

                    foreach (Vector2 cn in coin_pos_list)
                        spriteBatch.Draw(coin, cn, Color.White);

                    foreach (Vector2 en in enemy_pos_list)
                        spriteBatch.Draw(enemy, en, Color.White);
                    foreach (Vector2 en in enemy2_pos_list)
                        spriteBatch.Draw(enemy2, en, Color.White);

                    foreach (Vector2 sh in shot_pos_list)
                        spriteBatch.Draw(shot, sh, Color.White);
                    foreach (Vector2 sh in shot2_pos_list)
                        spriteBatch.Draw(shot2, sh, Color.White);

                    spriteBatch.DrawString(gameFont, ("Po�ng:" + point), new Vector2(10, 10), Color.Blue);
                    spriteBatch.DrawString(gameFont, ("Liv:" + hp), new Vector2(10, 40), Color.Red);
                    spriteBatch.DrawString(gameFont, ("Niv� " + lv), new Vector2(Window.ClientBounds.Width - 100, 10), Color.White);
                    break;

                case 4:
                    spriteBatch.Draw(myship, myship_pos, Color.White);

                    foreach (Vector2 cn in coin_pos_list)
                        spriteBatch.Draw(coin, cn, Color.White);

                    foreach (Vector2 en in enemy_pos_list)
                        spriteBatch.Draw(enemy, en, Color.White);
                    foreach (Vector2 en in enemy2_pos_list)
                        spriteBatch.Draw(enemy2, en, Color.White);

                    foreach (Vector2 sh in shot_pos_list)
                        spriteBatch.Draw(shot, sh, Color.White);
                    foreach (Vector2 sh in shot2_pos_list)
                        spriteBatch.Draw(shot2, sh, Color.White);

                    spriteBatch.DrawString(gameFont, ("Po�ng:" + point), new Vector2(10, 10), Color.Blue);
                    spriteBatch.DrawString(gameFont, ("Liv:" + hp), new Vector2(10, 40), Color.Red);
                    spriteBatch.DrawString(gameFont, ("Niv� " + lv), new Vector2(Window.ClientBounds.Width - 100, 10), Color.White);
                    break;

                case 5:
                    spriteBatch.Draw(myship, myship_pos, Color.White);

                    foreach (Vector2 cn in coin_pos_list)
                        spriteBatch.Draw(coin, cn, Color.White);

                    foreach (Vector2 en in enemy_pos_list)
                        spriteBatch.Draw(enemy, en, Color.White);
                    foreach (Vector2 en in enemy2_pos_list)
                        spriteBatch.Draw(enemy2, en, Color.White);

                    foreach (Vector2 sh in shot_pos_list)
                        spriteBatch.Draw(shot, sh, Color.White);
                    foreach (Vector2 sh in shot2_pos_list)
                        spriteBatch.Draw(shot2, sh, Color.White);

                    spriteBatch.DrawString(gameFont, ("Po�ng:" + point), new Vector2(10, 10), Color.Blue);
                    spriteBatch.DrawString(gameFont, ("Liv:" + hp), new Vector2(10, 40), Color.Red);
                    spriteBatch.DrawString(gameFont, ("Niv� " + lv), new Vector2(Window.ClientBounds.Width - 100, 10), Color.White);
                    break;

                case 6:
                    spriteBatch.Draw(myship, myship_pos, Color.White);
                    spriteBatch.Draw(boss, boss_pos, null, Color.White, 0.0f, Vector2.Zero, 1f, effect, 0);

                    foreach (Vector2 cn in coin_pos_list)
                        spriteBatch.Draw(coin, cn, Color.White);

                    foreach (Vector2 en in enemy_pos_list)
                        spriteBatch.Draw(enemy, en, Color.White);
                    foreach (Vector2 en in enemy2_pos_list)
                        spriteBatch.Draw(enemy2, en, Color.White);

                    foreach (Vector2 me in megashot_pos_list)
                        spriteBatch.Draw(megashot, me, Color.White);
                    foreach (Vector2 sh in shot_pos_list)
                        spriteBatch.Draw(shot, sh, Color.White);
                    foreach (Vector2 sh in shot2_pos_list)
                        spriteBatch.Draw(shot2, sh, Color.White);

                    spriteBatch.DrawString(gameFont, ("Po�ng:" + point), new Vector2(10, 10), Color.Blue);
                    spriteBatch.DrawString(gameFont, ("Liv:" + hp), new Vector2(10, 40), Color.Red);
                    spriteBatch.DrawString(gameFont, ("Niv� " + lv), new Vector2(Window.ClientBounds.Width - 100, 10), Color.White);
                    break;

                case 7:
                    spriteBatch.DrawString(gameFont, ("Spelet �r slut!"), new Vector2(300, 130), Color.White);
                    spriteBatch.DrawString(gameFont, ("Din slutpo�ng var " + point), new Vector2(300, 190), Color.White);

                    spriteBatch.DrawString(gameFont, ("Tillbaka till menyn"), new Vector2(300, 250), Color.White);
                    spriteBatch.DrawString(gameFont, ("Avsluta Spelet"), new Vector2(300, 280), Color.White);

                    if (select2 == 0)
                        spriteBatch.DrawString(gameFont, ("*"), new Vector2(285, 253), Color.White);
                    if (select2 == 1)
                        spriteBatch.DrawString(gameFont, ("*"), new Vector2(285, 283), Color.White);
                    break;

                case 8:
                    spriteBatch.DrawString(gameFont, ("H�gsta po�ng" + "\n1: " + a(highList) + "\n2: " + b(highList, a(highList)) + "\n3: " + c(highList, a(highList), b(highList, a(highList))) + "\n4: " + d(highList, a(highList), b(highList, a(highList)), c(highList, a(highList), b(highList, a(highList)))) + "\n5: " + f(highList, a(highList), b(highList, a(highList)), c(highList, a(highList), b(highList, a(highList))), d(highList, a(highList), b(highList, a(highList)), c(highList, a(highList), b(highList, a(highList)))))), new Vector2(320, 130), Color.White); //det funkar, men jag orkar inte t�nka p� f�rb�ttring
                    spriteBatch.DrawString(gameFont, ("Tryck mellanslag f�r att forts�tta till menyn"), new Vector2(170, 350), Color.White);
                    break;
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }

        //Stages
        public void menu(List<Var> varList)
        {
            KeyboardState keyboardState = Keyboard.GetState();
            
            if (timeSinceLastEnter >= 10)
            {
                if ((select == 1 && keyboardState.IsKeyDown(Keys.Up)) || (select == 2 && keyboardState.IsKeyDown(Keys.Down)))
                {
                    select = 0;                    
                }

                else if ((select == 0 && keyboardState.IsKeyDown(Keys.Down)) || (select == 2 && keyboardState.IsKeyDown(Keys.Up)))
                {
                    select = 1;
                }

                else if ((select == 0 && keyboardState.IsKeyDown(Keys.Up)) || (select == 1 && keyboardState.IsKeyDown(Keys.Down)))
                {
                    select = 2;
                }

                if (select == 0 && keyboardState.IsKeyDown(Keys.Enter))
                {
                    lv++;
                    ladda(varList);
                    varList[0].Lv = 1; 
                    varList[0].Bpup = 50;
                    varList[0].Hp = 30;
                    varList[0].Es = 0;
                    varList[0].Point = 0;
                    spara(varList);
                    ini = true; 
                }
                if (select == 1 && keyboardState.IsKeyDown(Keys.Enter))
                {
                    ladda(varList);
                    lv = varList[varList.Count-1].Lv;
                    if (lv == 6)
                        lv = 5;
                    bpup = varList[varList.Count - 1].Bpup;
                    hp = varList[varList.Count - 1].Hp;
                    e = varList[varList.Count - 1].Es;
                    point = varList[varList.Count - 1].Point;
                    if ((lv % 2) == 0)
                    {
                        ini = false;
                    }
                }
                if (select == 2 && keyboardState.IsKeyDown(Keys.Enter))
                {
                    laddahigh(highList);
                    lv = 8;
                }

                timeSinceLastEnter = 0;
            }
            timeSinceLastEnter++;
            
        }
        public void lv1()
        {
            createcoin(5);
            createenemy(10);
            temphp = hp;
            templv = lv;
            pup = true;
        }
        public void lv2()
        {
            createcoin(7);
            createenemy(20);
            temphp = hp;
            templv = lv;
            pup = true;
        }
        public void lv3()
        {
            createcoin(10);
            createenemy(20);
            createenemy2(5);
            templv = lv;
            temphp = hp;
            pup = true;
        }
        public void lv4()
        {
            createcoin(15);
            createenemy(10);
            createenemy2(10);
            templv = lv;
            temphp = hp;
            pup = true;
        }
        public void lv5()
        {
            createcoin(15);
            createenemy(20);
            createenemy2(10);
            templv = lv;
            temphp = hp;
            pup = true;
        }
        public void lv6()
        {
            createenemy(10);
            createenemy2(10);
            temphp = hp;
        }
        public void end()
        {
            KeyboardState keyboardState = Keyboard.GetState();
            if (timeSinceLastEnter >= 10)
            {
                if (select2 == 0 && (keyboardState.IsKeyDown(Keys.Up) || keyboardState.IsKeyDown(Keys.Down)))
                    select2 = 1;

                else if (select2 == 1 && (keyboardState.IsKeyDown(Keys.Up) || keyboardState.IsKeyDown(Keys.Down)))
                    select2 = 0;

                if (select2 == 0 && keyboardState.IsKeyDown(Keys.Enter)) // till menyn
                {
                    lv = 0;
                    bpup = 50;
                    hp = 30;
                    e = 0;
                    point = 0;

                    select = 0;
                }

                if (select2 == 1 && keyboardState.IsKeyDown(Keys.Enter)) // avsluta
                {
                    ladda(varList);
                    laddahigh(highList);

                    for (int i = 0; i < varList.Count; i++)
                    {
                        varList[i].Lv = templv;       
                        varList[i].Bpup = bpup;
                        if (hp > 0)
                        {
                            varList[i].Hp = hp;
                        }
                        else if (hp <= 0)
                        {
                            varList[i].Hp = temphp;
                        }
                        varList[i].Es = e;
                        varList[i].Point = point;
                    }
                    
                    spara(varList);

                    highList.Add(new Highscore(point));
                    sparahigh(highList);
                    Exit();
                }

                timeSinceLastEnter = 0;
            }
            timeSinceLastEnter++;
        }

        public void level()
        {
            //Update
            createship();
            updateenemy();
            updateenemy2();
            updateshot(bpup);
            updateshot2();
            updatemegashot();

            //General Logic
            if (point < 0)
                point = 0;

            //Collision Logic
            collision_sh_en();
            collision_sh_en2();
            collision_sh_boss();
            collision_myship_sh2();
            collision_myship_megashot();
            collision_myship_cn();            
            collision_myship_en();
            collision_myship_en2();
        }
        public void power(int a, int b)
        {
            if (coin_pos_list.Count == 0 && pup)
            {
                hp += a;
                bpup -= b;
                pup = false;
            }
        }
        public void terminate()
        {

            if ((enemy_pos_list.Count <= 0 && enemy2_pos_list.Count <= 0) && (hp > 0))
            {
                clearall();
                
                if ((enemy_pos_list.Count == 0 && enemy2_pos_list.Count == 0) && hp > 0)
                {
                    lv++;
                }  
            }

            else if (hp <= 0)
            {
                spara(varList);
                lv = 7;
            }
        }
        public void clearall()
        {
            for (int i = 0; i < coin_pos_list.Count; i++)
            {
                coin_pos_list.RemoveAt(i);
            }

            for (int i = 0; i < enemy_pos_list.Count; i++)
            {
                enemy_pos_list.RemoveAt(i);
            }

            for (int i = 0; i < enemy2_pos_list.Count; i++)
            {
                enemy2_pos_list.RemoveAt(i);
            }
        }

        //Initialize
        public void createship()
        {
            KeyboardState keyboardState = Keyboard.GetState();
            if (keyboardState.IsKeyDown(Keys.Left) || keyboardState.IsKeyDown(Keys.A))
                myship_pos.X = myship_pos.X - myship_speed.X;
            if (keyboardState.IsKeyDown(Keys.Right) || keyboardState.IsKeyDown(Keys.D))
                myship_pos.X = myship_pos.X + myship_speed.X;

            if (keyboardState.IsKeyDown(Keys.Up) || keyboardState.IsKeyDown(Keys.W))
                myship_pos.Y = myship_pos.Y - myship_speed.Y;
            if (keyboardState.IsKeyDown(Keys.Down) || keyboardState.IsKeyDown(Keys.S))
                myship_pos.Y = myship_pos.Y + myship_speed.Y;

            if (myship_pos.X < 0)
                myship_pos.X = 0;
            if (myship_pos.X > Window.ClientBounds.Width - myship.Width)
                myship_pos.X = Window.ClientBounds.Width - myship.Width;

            if (myship_pos.Y < 0)
                myship_pos.Y = 0;
            if (myship_pos.Y > Window.ClientBounds.Height - myship.Height)
                myship_pos.Y = Window.ClientBounds.Height - myship.Height;
        }
        public void createcoin(int n)
        {
            Random rand = new Random();
            for (int i = 0; i < n; i++)
            {
                coin_pos.X = rand.Next(0, Window.ClientBounds.Width - coin.Width);
                coin_pos.Y = rand.Next(0, Window.ClientBounds.Height - coin.Height);
                coin_pos_list.Add(coin_pos);
            }
        }
        public void createenemy(int n)
        {
            Random rand = new Random();
            for (int i = 0; i < n; i++)
            {
                enemy_pos.X = rand.Next(0, Window.ClientBounds.Width - enemy.Width);
                enemy_pos.Y = rand.Next(-200, -50);
                enemy_speed.Y = 1f;
                enemy_pos_list.Add(enemy_pos);
            }
        }
        public void createenemy2(int n)
        {
            Random rand = new Random();
            for (int i = 0; i < n; i++)
            {
                enemy2_pos.X = rand.Next(0, Window.ClientBounds.Width - enemy2.Width);
                enemy2_pos.Y = rand.Next(-150, -100);
                enemy2_speed.Y = 0.7f;
                enemy2_pos_list.Add(enemy2_pos);
            }
        }

        //Update
        public void updateenemy()
        {
            for (int i = 0; i < enemy_pos_list.Count; i++)
            {
                Vector2 temp_pos;
                temp_pos.X = enemy_pos_list.ElementAt(i).X;
                temp_pos.Y = enemy_pos_list.ElementAt(i).Y;
                temp_pos.Y = temp_pos.Y + enemy_speed.Y;
                enemy_pos_list.RemoveAt(i);
                enemy_pos_list.Insert(i, temp_pos);
                //rec_enemy = new Rectangle((int)(enemy_pos.X), (int)(enemy_pos.Y), enemy.Width, enemy.Height);
            }

            foreach (Vector2 en in enemy_pos_list.ToList())
            {
                if (en.Y > (Window.ClientBounds.Height - enemy.Height))
                {
                    enemy_pos_list.Remove(en);
                    hp -= 2;
                    e++;
                }
            }
        }
        public void updateenemy2()
        {
            for (int i = 0; i < enemy2_pos_list.Count; i++)
            {
                Vector2 temp_pos;
                temp_pos.X = enemy2_pos_list.ElementAt(i).X;
                temp_pos.Y = enemy2_pos_list.ElementAt(i).Y;
                temp_pos.Y = temp_pos.Y + enemy2_speed.Y;
                enemy2_pos_list.RemoveAt(i);
                enemy2_pos_list.Insert(i, temp_pos);
            }

            foreach (Vector2 en in enemy2_pos_list.ToList())
            {
                if (en.Y > (Window.ClientBounds.Height - enemy2.Height))
                {
                    enemy2_pos_list.Remove(en);
                    hp -= 5;
                    e++;
                }
            }
        }
        public void updateshot(int s)
        {
            KeyboardState keyboardState = Keyboard.GetState();
            shot_speed = new Vector2(0, -20);
            if (keyboardState.IsKeyDown(Keys.Space) && timeSinceLastBullet == 0)
            {
                shot_pos.X = (myship_pos.X + (myship.Width / 2)) - (shot.Width / 2);
                shot_pos.Y = myship_pos.Y;
                shot_pos_list.Add(shot_pos);
                myshot.Play();                
            }

            for (int i = 0; i < shot_pos_list.Count; i++)
            {
                shot_pos_list[i] += shot_speed;
                timeSinceLastBullet++;
            }
            if (timeSinceLastBullet > s || shot_pos_list.Count == 0)
                timeSinceLastBullet = 0;
        }
        public void updateshot2()
        {
            if (timeSinceLastBullet2 >= 100)
            {
                for (int i = 0; i < enemy2_pos_list.Count; i++)
                {
                    Vector2 temp_pos;
                    temp_pos.X = enemy2_pos_list.ElementAt(i).X;
                    temp_pos.Y = enemy2_pos_list.ElementAt(i).Y;
                    temp_pos.Y += enemy2_speed.Y;

                    shot2_speed = new Vector2(0, 5);
                    shot2_pos.X = temp_pos.X + (enemy2.Width - shot.Width) / 2;
                    shot2_pos.Y = temp_pos.Y + enemy2.Height;
                    shot2_pos_list.Add(shot2_pos);
                    myshot.Play();
                    timeSinceLastBullet2 = 0;
                }
                    
            }

            for (int i = 0; i < shot2_pos_list.Count; i++)
            {
                shot2_pos_list[i] += shot2_speed;
            }
            
            timeSinceLastBullet2++;            
        }
        public void updatemegashot()
        {
            megashot_speed = new Vector2(0, 1);
            if (timeSinceLastMega >= 90 && boss_pos.Y >= 50)
            {
                megashot_pos.X = (boss_pos.X + (boss.Width / 2)) - (megashot.Width / 2);
                megashot_pos.Y = boss_pos.Y + boss.Height;
                megashot_pos_list.Add(megashot_pos);
                //myshot.Play();
                timeSinceLastMega = 0;
            }
            
            timeSinceLastMega++;

            for (int i = 0; i < megashot_pos_list.Count; i++)
            {
                megashot_pos_list[i] += megashot_speed;
            }
        }
        public void updateboss()
        {
            boss_pos += boss_speed;
            if (boss_pos.Y < 50)
            {
                boss_speed.X = 0;
                boss_speed.Y = 5f;
                s = true;
            }            
            else if (s)
            {
                boss_speed.X = 3;
                boss_speed.Y = 0;
                s = false;
            }

            if ((boss_pos.X) > Window.ClientBounds.Width - boss.Width)
            {
                boss_speed.X = -boss_speed.X;
                effect = SpriteEffects.FlipHorizontally;
            }
            else if (boss_pos.X < 0)
            {
                boss_speed.X = -boss_speed.X;
                effect = SpriteEffects.None;
            }            
        }
        
        //Collision Logic
        public void collision_sh_en()
        {
            foreach (Vector2 sh in shot_pos_list.ToList())
            {
                foreach (Vector2 en in enemy_pos_list.ToList())
                {
                    rec_enemy = new Rectangle((int)(en.X), (int)(en.Y), enemy.Width, enemy.Height);
                    rec_shot = new Rectangle((int)(sh.X), (int)(sh.Y), shot.Width, shot.Height);

                    hit = CheckCollision(rec_shot, rec_enemy);
                    if (hit)
                    {
                        shot_pos_list.Remove(sh);
                        enemy_pos_list.Remove(en);
                        point += 20;
                        //mypunch.Play();
                        hit = false;
                    }
                }

                if (sh.Y < 0)
                    shot_pos_list.Remove(sh);
            }
        }
        public void collision_sh_en2()
        {
            foreach (Vector2 sh in shot_pos_list.ToList())
            {
                foreach (Vector2 en in enemy2_pos_list.ToList())
                {
                    rec_enemy2 = new Rectangle((int)(en.X), (int)(en.Y), enemy2.Width, enemy2.Height);
                    rec_shot = new Rectangle((int)(sh.X), (int)(sh.Y), shot.Width, shot.Height);

                    hit = CheckCollision(rec_shot, rec_enemy2);
                    if (hit)
                    {
                        shot_pos_list.Remove(sh);        
                        //mypunch.Play();
                        z++;
                        hit = false;
                    }
                    if (z >= 3)
                    {
                        enemy2_pos_list.Remove(en);
                        z = 0;
                        point += 40;
                    }
                }

                if (sh.Y < 0)
                    shot_pos_list.Remove(sh);
            }
        }
        public void collision_sh_boss()
        {
            foreach (Vector2 sh in shot_pos_list.ToList())
            {
                rec_shot = new Rectangle((int)(sh.X), (int)(sh.Y), shot.Width, shot.Height);
                rec_boss = new Rectangle((int)(boss_pos.X), (int)(boss_pos.Y), boss.Width, boss.Height);
                bool hit = CheckCollision(rec_shot, rec_boss);
                if (hit)
                {
                    shot_pos_list.Remove(sh);
                    bhp++;
                    point += 5;
                    //mypunch.Play();
                    if (bhp >= 30)
                    {
                        myshout.Play();
                        point += 500;
                        shout = true;
                        lv++;
                    }
                    hit = false;
                }
            }
        }
        public void collision_myship_sh2()
        {
            foreach (Vector2 sh in shot2_pos_list.ToList())
            {
                rec_myship = new Rectangle((int)(myship_pos.X), (int)(myship_pos.Y), myship.Width, myship.Height);
                rec_shot2 = new Rectangle((int)(sh.X), (int)(sh.Y), shot2.Width, shot2.Height);
                hit = CheckCollision(rec_myship, rec_shot2);
                if (hit)
                {
                    if (timeSinceLastHit3 >= 20)
                    {
                        shot2_pos_list.Remove(sh);
                        hp -= 3;
                        myoof.Play();
                        if (point >= 10)
                            point -= 10;
                        hit = false;
                        timeSinceLastHit3 = 0;
                    }                    
                }

                if (sh.Y > Window.ClientBounds.Height - shot2.Height)
                {
                    shot2_pos_list.Remove(sh);
                    hp -= 0.5f;
                    if (point >= 10)
                        point -= 10;
                }
            }

            if (timeSinceLastHit3 < 20)
            {
                timeSinceLastHit3++;
            }
        }
        public void collision_myship_megashot()
        {
            foreach (Vector2 me in megashot_pos_list.ToList())
            {
                rec_myship = new Rectangle((int)(myship_pos.X), (int)(myship_pos.Y), myship.Width, myship.Height);
                rec_megashot = new Rectangle((int)(me.X), (int)(me.Y), megashot.Width, megashot.Height);

                bool hit = CheckCollision(rec_myship, rec_megashot);
                if (hit)
                {                    
                    megashot_pos_list.Remove(me);
                    hp -= 5;
                    if (point >= 50)
                        point -= 50;
                    timeSinceLastHit4 = 0;
                    hit = false;
                    
                }
                if (me.Y > Window.ClientBounds.Height - megashot.Height)
                {
                    megashot_pos_list.Remove(me);
                    hp -= 5;
                    if (point >= 50)
                        point -= 50;
                }
            }
            if (timeSinceLastHit4 < 20)
            {
                timeSinceLastHit3++;
            }
        }
        public void collision_myship_cn()
        {
            foreach (Vector2 cn in coin_pos_list.ToList())
            {
                //rec_myship = new Rectangle((int)(myship_pos.X), (int)(myship_pos.Y), myship.Width, myship.Height);
                rec_coin = new Rectangle((int)(cn.X), (int)(cn.Y), coin.Width, coin.Height);
                rec_myship = new Rectangle((int)(myship_pos.X), (int)(myship_pos.Y), myship.Width, myship.Height);
                hit = CheckCollision(rec_myship, rec_coin);
                if (hit)
                {
                    coin_pos_list.Remove(cn);
                    point += 10;
                    hit = false;
                }
            }
        }
        public void collision_myship_en()
        {
            foreach (Vector2 en in enemy_pos_list.ToList())
            {
                rec_myship = new Rectangle((int)(myship_pos.X), (int)(myship_pos.Y), myship.Width, myship.Height);
                rec_enemy = new Rectangle((int)(en.X), (int)(en.Y), enemy.Width, enemy.Height);

                hit = CheckCollision(rec_myship, rec_enemy);
                if (hit)
                {
                    if (timeSinceLastHit1 >= 60)
                    {
                        hp -= 1;
                        if (point >= 15)
                        {
                            point -= 15;
                        }
                        myoof.Play();
                        timeSinceLastHit1 = 0;
                        e++;
                    }
                    hit = false;
                }
            }
            if (timeSinceLastHit1 < 60)
            {
                timeSinceLastHit1++;
            }
        }
        public void collision_myship_en2()
        {
            foreach (Vector2 en in enemy2_pos_list.ToList())
            {
                rec_myship = new Rectangle((int)(myship_pos.X), (int)(myship_pos.Y), myship.Width, myship.Height);
                rec_enemy2 = new Rectangle((int)(en.X), (int)(en.Y), enemy2.Width, enemy2.Height);
                hit = CheckCollision(rec_myship, rec_enemy2);
                if (hit == true)
                {
                    if (timeSinceLastHit1 >= 60)
                    {
                        hp -= 2;
                        if (point >= 20)
                        {
                            point -= 20;
                        }
                        myoof.Play();
                        timeSinceLastHit1 = 0;
                        e++;
                    }
                    hit = false;
                }
            }
            if (timeSinceLastHit1 < 60)
            {
                timeSinceLastHit1++;
            }
        }
        
        //Collision Function
        public bool CheckCollision(Rectangle a, Rectangle b)
        {
            return b.Intersects(a);
        }

        static void ladda(List<Var> varList)
        {
            StreamReader lasfil = new StreamReader("save.txt");
            string s;

            while ((s = lasfil.ReadLine()) != null)
            {
                string[] save = s.Split(',');

                string a = save[0];
                int lv = int.Parse(a);

                string b = save[1];
                int bpup = int.Parse(b);

                string c = save[2];
                float hp = int.Parse(c);

                string d = save[3];
                int f = int.Parse(d);

                string e = save[4];
                int point = int.Parse(e);

                varList.Add(new Var(lv, bpup, hp, f, point));
            }
            lasfil.Close();
        }
        static void spara(List<Var> varList)
        {            
            StreamWriter skrivfil = new StreamWriter("save.txt");
            skrivfil.WriteLine(varList[varList.Count - 1].Lv + "," + varList[varList.Count - 1].Bpup + "," + varList[varList.Count - 1].Hp + "," + varList[varList.Count - 1].Es + "," + varList[varList.Count - 1].Point);
            
            skrivfil.Close();
        }

        static void laddahigh(List<Highscore> highList)
        {
            StreamReader lasfil = new StreamReader("highscore.txt");
            string s;
            while ((s = lasfil.ReadLine())!= null)
            {
                string[] save = s.Split(' '); //beh�vs inte f�r det finns ju bara ett objekt per rad, men den vill bli tillsatt n�got f�r att kunna l�sa upp

                string a = save[0];
                int h = int.Parse(a);

                highList.Add(new Highscore(h));
            }
            lasfil.Close();
        }
        static void sparahigh(List<Highscore> highList)
        {
            StreamWriter skrivfil = new StreamWriter("highscore.txt");
            for (int i = 0; i < highList.Count; i++)
            {
                skrivfil.WriteLine(highList[i].High);
            }
            skrivfil.Close();
        }

        /// har tv� spelare samma po�ng kommer bara ett av dem visas. Det skulle kunna �tg�rdas 
        /// om jag gav varje po�ng ett specifikt id i listan
        public int a(List<Highscore> highList)
        {
            int o = 0;
            for (int i = 0; i < highList.Count; i++)
            {
                if (o < highList[i].High)
                {
                    o = highList[i].High;
                }
            }
            return o;
        } 
        public int b(List<Highscore> highList, int a)
        {
            int o = 0;
            for (int i = 0; i < highList.Count; i++)
            {
                if (o < highList[i].High && a != highList[i].High)
                {
                    o = highList[i].High;                    
                }
            }
            return o;
        }        
        public int c(List<Highscore> highList, int a, int b)
        {
            int o = 0;
            for (int i = 0; i < highList.Count; i++)
            {
                if (o < highList[i].High && a != highList[i].High && b != highList[i].High)
                {
                    o = highList[i].High;
                }
            }
            return o;
        }        
        public int d(List<Highscore> highList, int a, int b, int c)
        {
            int o = 0;
            for (int i = 0; i < highList.Count; i++)
            {
                if (o < highList[i].High && a != highList[i].High && b != highList[i].High && c != highList[i].High)
                {
                    o = highList[i].High;
                }
            }
            return o;
        }        
        public int f(List<Highscore> highList, int a, int b, int c, int d)
        {
        int o = 0;
            for (int i = 0; i < highList.Count; i++)
            {
                if (o < highList[i].High && a != highList[i].High && b != highList[i].High && c != highList[i].High && d!= highList[i].High)
                {
                    o = highList[i].High;
                }
            }
            return o;
        }
    } 
}