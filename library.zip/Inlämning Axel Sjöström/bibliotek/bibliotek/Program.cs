﻿//Axel Sjöström TE16a
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace bibliotek
{
    class Back
    {
        private string namn;
        private string titel;
        private int lan;

        public Back(string n, string t, int l)
        {
            namn = n;
            titel = t;
            lan = l;
        }
        public string Namn
        {
            get { return namn; }
            set { namn = value; }
        }
        public string Titel
        {
            get { return titel; }
            set { titel = value; }
        }
        public int Lan
        {
            get { return lan; }
            set { lan = value; }
        }
    }
    class Program
    {
        static void lasupp(List<Back> bibList)
        {
            StreamReader lasfil = new StreamReader("bibliotek.txt");
            string s;

            while ((s = lasfil.ReadLine()) != null)
            {
                string[] bokdata = s.Split(',');
                string namn = bokdata[0];
                string titel = bokdata[1];
                string templ = bokdata[2];
                int l = int.Parse(templ);

                bibList.Add(new Back(namn, titel, l));
            }
            lasfil.Close();
        }
        static void spara(List<Back> bibList)
        {
            StreamWriter skrivfil = new StreamWriter("bibliotek.txt");
            for (int i = 0; i < bibList.Count; i++)
            {
                skrivfil.WriteLine(bibList[i].Namn + "," + bibList[i].Titel + "," + bibList[i].Lan);
            }
            skrivfil.Close();
        }

        static void sokbok(List<Back> bibList)
        {
            Console.Write("Skriv bok att söka efter:");
            string soknr = Console.ReadLine();
            int k = 0;

            for (int i = 0; i < bibList.Count; i++)
            {
                if (bibList[i].Titel == soknr)
                    k++;
            }

            if (k == 0)
                Console.WriteLine("\nBoken hittades inte. Är du säker på att du stavade rätt?");

            for (int i = 0; i < bibList.Count; i++)
            {
                if (bibList[i].Titel == soknr && bibList[i].Lan == 0)
                    Console.WriteLine(bibList[i].Namn + ":" + bibList[i].Titel + ", ej utlånad");

                else if (bibList[i].Titel == soknr && bibList[i].Lan == 1)
                    Console.WriteLine(bibList[i].Namn + ":" + bibList[i].Titel + ", utlånad");
            }
        }
        static void sokforf(List<Back> bibList)
        {
            Console.Write("Skriv författare att söka efter:");
            string soknr = Console.ReadLine();

            int k = 0;

            for (int i = 0; i < bibList.Count; i++)
            {
                if (bibList[i].Namn == soknr && bibList[i].Lan == 0)
                    k++;

                else if (bibList[i].Namn == soknr && bibList[i].Lan == 1)
                    k++;
            }
            if (k > 1)
                Console.WriteLine("\nHittade " + k + " böcker:\n");

            else if (k == 1)
                Console.WriteLine("\nHittade 1 bok:\n");

            else
                Console.WriteLine("\nFörfattaren hittades inte. Är du säker på att du stavade rätt?");

            for (int i = 0; i < bibList.Count; i++)
            {
                if (bibList[i].Namn == soknr && bibList[i].Lan == 0)
                    Console.WriteLine(bibList[i].Namn + ":" + bibList[i].Titel + ", ej utlånad");

                else if (bibList[i].Namn == soknr && bibList[i].Lan == 1)
                    Console.WriteLine(bibList[i].Namn + ":" + bibList[i].Titel + ", utlånad");
            }

        }
        static void lana(List<Back> bibList)
        {
            Console.WriteLine("Böcker att låna:");
            for (int i = 0; i < bibList.Count; i++)
            {
                if (bibList[i].Lan == 0)
                    Console.WriteLine(bibList[i].Namn + ":" + bibList[i].Titel);
            }

            Console.Write("Du vill låna:");
            string templan = Console.ReadLine();

            int k = 0;

            for (int i = 0; i < bibList.Count; i++)
            {
                if (templan == bibList[i].Titel)
                {
                    bibList[i].Lan = 1;
                    k++;
                    Console.WriteLine("Lån genomfört.");
                }
            }

            if (k == 0)
                Console.WriteLine("Boken finns inte tillgänglig.");
        }
        static void lamna(List<Back> bibList)
        {
            Console.Write("Skriv in bok att återlämna:");
            string templamna = Console.ReadLine();

            int k = 0;

            for (int i = 0; i < bibList.Count; i++)
            {
                if (templamna == bibList[i].Titel)
                {
                    bibList[i].Lan = 0;
                    k++;
                }
            }

            if (k == 0)
                Console.WriteLine("Ingen bok lämnades tillbaka. Är du säker på att du lånat boken/stavat rätt?");
            else
                Console.WriteLine("Bok återlämnad");
        }
        static void laggtill(List<Back> bibList)
        {
            Console.Write("\nLägg till ny bok:\nTitel:");
            string temptitel = Console.ReadLine();

            Console.Write("Författare:");
            string tempforfattare = Console.ReadLine();

            int l = 0;

            bibList.Add(new Back(tempforfattare, temptitel, l));
        }
        static void tabortf(List<Back> bibList)
        {
            Console.Write("Ange författare att ta bort:");
            string sokforf = Console.ReadLine();

            for (int i = 0; i < bibList.Count; i++)
            {
                if (sokforf == bibList[i].Namn)
                {
                    bibList.RemoveAt(i);
                    i--;
                }
            }

            Console.WriteLine("Författare borttagna");
        }
        static void tabortb(List<Back> bibList)
        {
            Console.Write("Ange bok att ta bort:");
            string sokbok = Console.ReadLine();

            for (int i = 0; i < bibList.Count; i++)
            {
                if (sokbok == bibList[i].Titel)
                {
                    bibList.RemoveAt(i);
                    i--;
                }
            }

            Console.WriteLine("Bok borttagen");
        }
        static void all(List<Back> bibList)
        {
            for (int i = 0; i < bibList.Count; i++)
            {
                if (bibList[i].Lan == 0)
                    Console.WriteLine("\nFörfattare: " + bibList[i].Namn + " \nTitel: " + bibList[i].Titel + "\nEj utlånad");

                else if (bibList[i].Lan == 1)
                    Console.WriteLine("\nFörfattare: " + bibList[i].Namn + " \nTitel: " + bibList[i].Titel + "\nUtlånad");
            }
        }
        static void inst()
        {
            Console.WriteLine("\nT söka på Titel.\nF söka på Författare.\nL Låna bok.\nÅ Återlämna bok.\nN lägga in Ny bok.\nBF ta Bort Författare\nBB ta Bort Bok.\nA lista alla böcker.\nK visa denna Kommandolista\nS Sluta.\n");
        }

        static void fel()
        {
            Console.WriteLine("Kommandot finns inte, Skriv K för att visa Kommandolistan igen. Om inte, tryck på valfri tangent.");
            string opt = Console.ReadLine();
            if (opt == "K" || opt == "k")
                inst();
        }
        static string act(string o)
        {
            Console.Write("\nSkriv din aktion:");
            return Console.ReadLine();
        }

        static void Main(string[] args)
        {
            List<Back> bibList = new List<Back>();

            //Ta från externt dokument
            lasupp(bibList);

            Console.WriteLine("Välkommen till biblioteksprogrammet!");
            inst();
            Console.Write("Skriv din aktion:");
            string opt = Console.ReadLine();

            while (opt != "S" && opt != "s" )
            {
                if (opt == "T" || opt == "t")
                    sokbok(bibList);

                else if (opt == "F" || opt == "f")
                    sokforf(bibList);

                else if (opt == "L" || opt == "l")
                    lana(bibList);

                else if (opt == "Å" || opt == "å")
                    lamna(bibList);

                else if (opt == "N" || opt == "n")
                    laggtill(bibList);

                else if (opt == "BB" || opt == "Bb" || opt == "bB" || opt == "bb")
                    tabortb(bibList);

                else if (opt == "BF" || opt == "Bf" || opt == "bF" || opt == "bf")
                    tabortf(bibList);

                else if (opt == "A" || opt == "a")
                    all(bibList);

                else if (opt == "K" || opt == "k")
                    inst();

                else
                    fel();
                  
                opt = act(opt);
            }
            spara(bibList);
        }
    }
}